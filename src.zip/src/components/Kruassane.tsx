export default function Kruassane() {
  return <div>Kruassane</div>
}
