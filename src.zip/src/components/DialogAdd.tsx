import { useFormik } from "formik"
import { useDispatch } from "react-redux"
import { addUser } from "../store/createSlice"
import type { AppDispatch } from "../store/store"

interface DialogAddProps {
  open: boolean
  onClose: () => void
}

export default function DialogAdd({ open, onClose }: DialogAddProps) {
  const dispatch = useDispatch<AppDispatch>()

  const formik = useFormik({
    initialValues: {
      name: "",
      age: "",
      status: false,
    },
    onSubmit: (values) => {
      dispatch(
        addUser({
          name: values.name,
          age: values.age ? Number(values.age) : undefined,
          status: values.status,
        })
      )
      formik.resetForm()
      onClose()
    },
  })

  if (!open) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-xl w-96 shadow-lg text-black">
        <h2 className="text-xl font-bold mb-4">Илова кардани корбар</h2>

        <form onSubmit={formik.handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Ном</label>
            <input
              type="text"
              name="name"
              placeholder="Номи корбар..."
              value={formik.values.name}
              onChange={formik.handleChange}
              className="border border-gray-300 w-full p-2 rounded-lg outline-none focus:border-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Синну сол</label>
            <input
              type="number"
              name="age"
              placeholder="Синну сол..."
              value={formik.values.age}
              onChange={formik.handleChange}
              className="border border-gray-300 w-full p-2 rounded-lg outline-none focus:border-blue-500"
            />
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              name="status"
              checked={formik.values.status}
              onChange={formik.handleChange}
              className="w-4 h-4 cursor-pointer"
            />
            <span className="text-sm font-medium">Статус (Online)</span>
          </label>

          <div className="flex justify-end gap-2 mt-2">
            <button
              type="button"
              onClick={() => {
                formik.resetForm()
                onClose()
              }}
              className="px-4 py-2 border rounded-lg hover:bg-gray-100 transition cursor-pointer"
            >
              Бекор кардан
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition cursor-pointer"
            >
              Сабт кардан
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
