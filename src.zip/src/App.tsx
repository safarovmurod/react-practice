import Coffe from "./components/Coffe"
import Kruassane from "./components/Kruassane"
import Order from "./components/Order"
import Restart from "./components/Restart"

export default function App() {
  return (
    <div>
      <Order />
      <Coffe />
      <Kruassane />
      <Coffe />
      <Restart />
    </div>
  )
}
