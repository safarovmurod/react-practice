import { useDispatch, useSelector } from "react-redux"
import { deleteUser, getUsers } from "./store/createSlice"
import { useEffect, useState } from "react"
import type { RootState, AppDispatch } from "./store/store"
import DialogAdd from "./components/DialogAdd"

export default function App() {
  const { data, loading, error } = useSelector((state: RootState) => state.data)
  const dispatch = useDispatch<AppDispatch>()
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    dispatch(getUsers())
  }, [dispatch])

  return (
    <div>
      <div>
        <button
          onClick={() => setIsOpen(true)}
          className="border-[1px] p-[4px] rounded-lg text-[black] bg-gray-300 cursor-pointer"
        >
          add user
        </button>
      </div>

      <DialogAdd open={isOpen} onClose={() => setIsOpen(false)} />
      {loading && <h2>Loading...</h2>}
      {error && <h2 style={{ color: "red" }}>{error}</h2>}
      {data?.map((el) => {
        return (
          <div key={el.id}>
            <h4>{el.name}</h4>
            <h4>{el.status ? "online" : "offline"}</h4>
            <button className="border-[1px] p-[10px]" onClick={() => dispatch(deleteUser(el.id))}>
              delete
            </button>
          </div>
        )
      })}
    </div>
  )
}
