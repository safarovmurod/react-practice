import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import type { InitialState, User } from "../component/types"
import axios from "axios"
import { api } from "../data/api"


export const getUsers = createAsyncThunk("data/getUsers", async (_, { rejectWithValue }) => {
  try {
    const { data } = await axios.get(api)
    return data
  } catch (error: any) {
    return rejectWithValue(error.message || "Error")
  }
})

export const deleteUser = createAsyncThunk("data/deleteUser", async (id: number | string, { dispatch }) => {
  try {
      await axios.delete(`${api}/${id}`)
      dispatch(getUsers())
  } catch (error) {
    console.error("delete ошыбка дод чураааа");
  }
}) 

export const addUser = createAsyncThunk("data/addUser", async (newUser: Partial<User>, { dispatch }) => {
  try {
    await axios.post(api, newUser)
    dispatch(getUsers())
  } catch (error) {
    console.error("add ошыбка дод чураааа")
  }
}) 

const initialState: InitialState = {
  data: [],
  loading: false,
  error: null,
}

export const dataSlice = createSlice({
  name: "data",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getUsers.pending, (state) => {
        state.loading = true
        state.error = null
      })

      .addCase(getUsers.fulfilled, (state, action) => {
        state.loading = false
        state.data = action.payload || []
      })

      .addCase(getUsers.rejected, (state, action) => {
        state.loading = false
        state.error = (action.payload as string) || action.error.message || "Error"
      })
  },
})

export default dataSlice.reducer
