export type User = {
  id?: number | string
  name: string
  status?: boolean
  age?: number | string
}

export type InitialState = {
  data: User[]
  loading: boolean
  error: string | null
}
